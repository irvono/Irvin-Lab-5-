﻿using Ono.DAL;
using Ono.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ono.Controllers
{
    public class EditInfoController : Controller
    {
        // GET: EditInfo
        public ActionResult Index()
        {
            OnoContext db = new OnoContext();
            var users = from u in db.Users.Include("Photos")
                          where u.FirstName == "Alexander"
                          select u;
 


            var vm = new List<PhotoViewModel>();
            foreach(User u in users)
            {
   
                foreach(Photo p in u.Photos)
                {
                    vm.Add(new PhotoViewModel() {
                                Name=p.Name,
                                User = new UserViewModel() {FirstName=u.FirstName }
                                });
                }
            }

            return View(vm);
        }
        }
    }
